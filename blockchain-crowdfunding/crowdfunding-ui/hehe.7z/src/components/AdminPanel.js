import React from "react";

const AdminPanel = () => {
  return (
    <div>
      <h2>Admin Panel</h2>
      <p>Welcome, Admin! Here are your controls:</p>
      <ul>
        <li>✅ Pause/Unpause Campaigns</li>
        <li>✅ View All Campaigns</li>
        <li>✅ Manage Users</li>
      </ul>
    </div>
  );
};

export default AdminPanel;
