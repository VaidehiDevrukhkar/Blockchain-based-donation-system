// NGODashboard.js
import React, { useState, useEffect } from "react";
import { BrowserProvider, Contract, parseEther, formatEther } from "ethers";
// import CrowdfundingABI from "../src/contracts/Crowdfunding.json";
import Crowdfunding from '../contracts/Crowdfunding.json';


const CONTRACT_ADDRESS = "0xae13FbE7152f3DE0Eb7cF759AdE6aB5bC0aaA73E";

function NGODashboard({ user, currentAccount }) {
  const [myCampaigns, setMyCampaigns] = useState([]);
  const [newCampaign, setNewCampaign] = useState({
    name: "",
    description: "",
    goal: "",
    duration: "",
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user && currentAccount) {
      fetchMyCampaigns();
    }
  }, [user, currentAccount]);

  async function fetchMyCampaigns() {
    if (!window.ethereum || !currentAccount) return;

    setLoading(true);
    const provider = new BrowserProvider(window.ethereum);
    const contract = new Contract(CONTRACT_ADDRESS, Crowdfunding.abi, provider);

    try {
      const count = await contract.campaignCount();
      let fetchedCampaigns = [];

      for (let i = 0; i < count; i++) {
        const campaign = await contract.campaigns(i);
        if (campaign.owner.toLowerCase() === currentAccount.toLowerCase()) {
          fetchedCampaigns.push({
            id: i,
            name: campaign.name,
            description: campaign.description,
            goal: formatEther(campaign.goal),
            raised: formatEther(campaign.balance),
            creator: campaign.owner,
          });
        }
      }

      setMyCampaigns(fetchedCampaigns);
    } catch (error) {
      console.error("Error fetching campaigns:", error);
    } finally {
      setLoading(false);
    }
  }

  async function createCampaign() {
    if (!user) return alert("Only logged-in NGOs can create campaigns");
    if (!window.ethereum) return alert("MetaMask is required");

    setLoading(true);
    const provider = new BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const contract = new Contract(CONTRACT_ADDRESS, Crowdfunding.abi, signer);

    try {
      const txn = await contract.createCampaign(
        newCampaign.name,
        newCampaign.description,
        parseEther(newCampaign.goal),
        newCampaign.duration
      );
      await txn.wait();

      alert("Campaign Created!");
      fetchMyCampaigns();
      // Reset form
      setNewCampaign({
        name: "",
        description: "",
        goal: "",
        duration: "",
      });
    } catch (error) {
      console.error("Error creating campaign:", error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="ngo-dashboard">
      <h1>NGO Dashboard</h1>
      <div className="campaign-form">
        <h2>Create a Campaign</h2>
        <input 
          type="text" 
          placeholder="Name" 
          value={newCampaign.name}
          onChange={(e) => setNewCampaign({ ...newCampaign, name: e.target.value })} 
        />
        <input 
          type="text" 
          placeholder="Description" 
          value={newCampaign.description}
          onChange={(e) => setNewCampaign({ ...newCampaign, description: e.target.value })} 
        />
        <input 
          type="number" 
          placeholder="Goal (ETH)" 
          value={newCampaign.goal}
          onChange={(e) => setNewCampaign({ ...newCampaign, goal: e.target.value })} 
        />
        <input 
          type="number" 
          placeholder="Duration (days)" 
          value={newCampaign.duration}
          onChange={(e) => setNewCampaign({ ...newCampaign, duration: e.target.value })} 
        />
        <button onClick={createCampaign} disabled={loading}>
          {loading ? "Creating..." : "Create Campaign"}
        </button>
      </div>

      <div className="my-campaigns">
        <h2>My Campaigns</h2>
        {loading ? (
          <p>Loading campaigns...</p>
        ) : myCampaigns.length > 0 ? (
          myCampaigns.map((campaign) => (
            <div key={campaign.id} className="campaign-card">
              <h3>{campaign.name}</h3>
              <p>{campaign.description}</p>
              <p>Goal: {campaign.goal} ETH | Raised: {campaign.raised} ETH</p>
              <div className="progress-bar">
                <div 
                  className="progress" 
                  style={{ width: `${Math.min((campaign.raised / campaign.goal) * 100, 100)}%` }}
                ></div>
              </div>
            </div>
          ))
        ) : (
          <p>No campaigns created yet.</p>
        )}
      </div>
    </div>
  );
}

export default NGODashboard;