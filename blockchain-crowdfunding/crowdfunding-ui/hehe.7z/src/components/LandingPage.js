import React, { useState } from "react";
import "./LandingPage.css";

const LandingPage = () => {
  const [showModal, setShowModal] = useState(false);

  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  return (
    <div className="landing-container">
      <button onClick={openModal}>Open Modal</button>
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <button className="close-button" onClick={closeModal}>×</button>
            <h3>Get Started</h3>
          </div>
        </div>
      )}
    </div>
  );
};

export default LandingPage;