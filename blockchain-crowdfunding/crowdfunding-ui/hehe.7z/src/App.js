// import React, { useState, useEffect } from "react";
// import { BrowserProvider, Contract, parseEther, formatEther } from "ethers";
// import {
//   auth,
//   provider,
//   signInWithPopup,
//   signInWithEmailAndPassword,
//   signOut,
// } from "./firebaseConfig";
// import { getFirestore, collection, addDoc, getDocs } from "firebase/firestore"; // Firestore Imports
// import CrowdfundingABI from "../src/contracts/Crowdfunding.json"; // Smart Contract ABI
// import LandingPage from "./components/LandingPage";

// const CONTRACT_ADDRESS = "0xae13FbE7152f3DE0Eb7cF759AdE6aB5bC0aaA73E";

// function App() {
//   const [currentAccount, setCurrentAccount] = useState(null);
//   const [user, setUser] = useState(null);
//   const [allCampaigns, setAllCampaigns] = useState([]);
//   const [myCampaigns, setMyCampaigns] = useState([]);
//   const [donationAmounts, setDonationAmounts] = useState({});
//   const [newCampaign, setNewCampaign] = useState({
//     name: "",
//     description: "",
//     goal: "",
//     duration: "",
//   });
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");

//   const db = getFirestore(); // Initialize Firestore

//   useEffect(() => {
//     checkWalletConnection();
//     fetchCampaigns();
//   }, [user, currentAccount]);

//   async function checkWalletConnection() {
//     if (window.ethereum) {
//       const accounts = await window.ethereum.request({ method: "eth_accounts" });
//       if (accounts.length > 0) setCurrentAccount(accounts[0]);
//     }
//   }

//   async function connectWallet() {
//     if (!window.ethereum) return alert("MetaMask not detected!");
//     const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
//     setCurrentAccount(accounts[0]);
//   }

//   async function googleLogin() {
//     try {
//       const result = await signInWithPopup(auth, provider);
//       setUser(result.user);
//       fetchCampaigns();
//     } catch (error) {
//       console.error("Google Login Error:", error.message);
//     }
//   }

//   async function emailLogin() {
//     try {
//       const result = await signInWithEmailAndPassword(auth, email, password);
//       setUser(result.user);
//       fetchCampaigns();
//     } catch (error) {
//       console.error("Email Login Error:", error.message);
//       alert("Invalid Credentials");
//     }
//   }

//   function logout() {
//     signOut(auth);
//     setUser(null);
//     setMyCampaigns([]);
//   }

//   async function fetchCampaigns() {
//     if (!window.ethereum) return;
//     const provider = new BrowserProvider(window.ethereum);
//     const contract = new Contract(CONTRACT_ADDRESS, CrowdfundingABI.abi, provider);

//     try {
//       const count = await contract.campaignCount();
//       let fetchedCampaigns = [];

//       for (let i = 0; i < count; i++) {
//         const campaign = await contract.campaigns(i);
//         fetchedCampaigns.push({
//           id: i,
//           name: campaign.name,
//           description: campaign.description,
//           goal: formatEther(campaign.goal),
//           raised: formatEther(campaign.balance),
//           creator: campaign.owner,
//         });
//       }

//       setAllCampaigns(fetchedCampaigns);

//       if (user && currentAccount) {
//         const filteredCampaigns = fetchedCampaigns.filter(
//           (c) => c.creator.toLowerCase() === currentAccount.toLowerCase()
//         );
//         setMyCampaigns(filteredCampaigns);
//       }
//     } catch (error) {
//       console.error("Error fetching campaigns:", error);
//     }
//   }

//   async function createCampaign() {
//     if (!user) return alert("Only logged-in NGOs can create campaigns");
//     if (!window.ethereum) return alert("MetaMask is required");

//     const provider = new BrowserProvider(window.ethereum);
//     const signer = await provider.getSigner();
//     const contract = new Contract(CONTRACT_ADDRESS, CrowdfundingABI.abi, signer);

//     try {
//       const txn = await contract.createCampaign(
//         newCampaign.name,
//         newCampaign.description,
//         parseEther(newCampaign.goal),
//         newCampaign.duration
//       );
//       await txn.wait();

//       // Save campaign to Firestore
//       await addDoc(collection(db, "campaigns"), {
//         name: newCampaign.name,
//         description: newCampaign.description,
//         goal: newCampaign.goal,
//         duration: newCampaign.duration,
//         creator: user.email,
//       });

//       alert("Campaign Created!");
//       fetchCampaigns();
//     } catch (error) {
//       console.error("Error creating campaign:", error);
//     }
//   }

//   async function donateToCampaign(campaignId) {
//     if (!currentAccount) return alert("Connect MetaMask first!");
//     const donationAmount = donationAmounts[campaignId];

//     if (!donationAmount || isNaN(donationAmount) || Number(donationAmount) <= 0) {
//       return alert("Enter a valid donation amount.");
//     }

//     const provider = new BrowserProvider(window.ethereum);
//     const signer = await provider.getSigner();
//     const contract = new Contract(CONTRACT_ADDRESS, CrowdfundingABI.abi, signer);

//     try {
//       const txn = await contract.contribute(campaignId, {
//         value: parseEther(donationAmount),
//       });
//       await txn.wait();
//       alert(`Successfully donated ${donationAmount} ETH!`);
//       fetchCampaigns();
//     } catch (error) {
//       console.error("Error donating:", error);
//     }
//   }

//   return (
//     <div>
//       <h1>Blockchain Crowdfunding</h1>

//       {/* 🔹 Firebase Login */}
//       {!user ? (
//         <div>
//           <h2>NGO Login</h2>
//           <input type="email" placeholder="Email" onChange={(e) => setEmail(e.target.value)} />
//           <input type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
//           <button onClick={emailLogin}>Login with Email</button>
//           <button onClick={googleLogin}>Login with Google</button>
//         </div>
//       ) : (
//         <div>
//           <p>Welcome, {user.email}</p>
//           <button onClick={logout}>Logout</button>
//         </div>
//       )}

//       {/* 🔹 MetaMask Connection */}
//       {!currentAccount ? (
//         <button onClick={connectWallet}>Connect MetaMask</button>
//       ) : (
//         <p>Connected: {currentAccount}</p>
//       )}

//       {/* 🔹 Campaign Creation (Only for NGOs) */}
//       {user && (
//         <div>
//           <h2>Create a Campaign</h2>
//           <input type="text" placeholder="Name" onChange={(e) => setNewCampaign({ ...newCampaign, name: e.target.value })} />
//           <input type="text" placeholder="Description" onChange={(e) => setNewCampaign({ ...newCampaign, description: e.target.value })} />
//           <input type="number" placeholder="Goal (ETH)" onChange={(e) => setNewCampaign({ ...newCampaign, goal: e.target.value })} />
//           <input type="number" placeholder="Duration (days)" onChange={(e) => setNewCampaign({ ...newCampaign, duration: e.target.value })} />
//           <button onClick={createCampaign}>Create Campaign</button>
//         </div>
//       )}

//       {/* 🔹 Show My Campaigns */}
//       {user && (
//         <div>
//           <h2>My Campaigns</h2>
//           {myCampaigns.length > 0 ? (
//             myCampaigns.map((campaign) => (
//               <div key={campaign.id}>
//                 <h3>{campaign.name}</h3>
//                 <p>{campaign.description}</p>
//                 <p>Goal: {campaign.goal} ETH | Raised: {campaign.raised} ETH</p>
//               </div>
//             ))
//           ) : (
//             <p>No campaigns created yet.</p>
//           )}
//         </div>
//       )}

//       {/* 🔹 Show All Campaigns */}
//       <h2>All Campaigns</h2>
//       {allCampaigns.map((campaign) => (
//         <div key={campaign.id}>
//           <h3>{campaign.name}</h3>
//           <p>{campaign.description}</p>
//           <p>Goal: {campaign.goal} ETH | Raised: {campaign.raised} ETH</p>
//           <input type="number" placeholder="Enter amount" onChange={(e) => setDonationAmounts({ ...donationAmounts, [campaign.id]: e.target.value })} />
//           <button onClick={() => donateToCampaign(campaign.id)}>Donate</button>
//         </div>
//       ))}
//     </div>
//   );
// }

// export default App;


import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { BrowserProvider } from "ethers";
import {
  auth,
  provider,
  signInWithPopup,
  signInWithEmailAndPassword,
  signOut,
} from "./firebaseConfig";
import LandingPage from "./components/LandingPage";
import NGODashboard from "./components/NGODashboard";
import DonationPage from "./components/DonationPage";
import AdminPanel from "./components/AdminPanel"; // Import Admin Panel
import "./App.css";

function App() {
  const [currentAccount, setCurrentAccount] = useState(null);
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    checkWalletConnection();
  }, []);

  async function checkWalletConnection() {
    if (window.ethereum) {
      const accounts = await window.ethereum.request({ method: "eth_accounts" });
      if (accounts.length > 0) setCurrentAccount(accounts[0]);
    }
  }

  async function connectWallet() {
    if (!window.ethereum) return alert("MetaMask not detected!");
    const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
    setCurrentAccount(accounts[0]);
  }

  async function googleLogin() {
    try {
      const result = await signInWithPopup(auth, provider);
      setUser(result.user);
    } catch (error) {
      console.error("Google Login Error:", error.message);
    }
  }

  async function emailLogin() {
    try {
      const result = await signInWithEmailAndPassword(auth, email, password);
      setUser(result.user);
    } catch (error) {
      console.error("Email Login Error:", error.message);
      alert("Invalid Credentials");
    }
  }

  function logout() {
    signOut(auth);
    setUser(null);
  }

  return (
    <Router>
      <div className="app">
        <header className="app-header">
          <h1>Blockchain Crowdfunding</h1>
          <nav>
            <ul>
              <li><Link to="/">Home</Link></li>
              <li><Link to="/donate">Donate</Link></li>
              {user && <li><Link to="/ngo-dashboard">NGO Dashboard</Link></li>}
              {user?.email === "admin@example.com" && <li><Link to="/admin">Admin Panel</Link></li>}
            </ul>
          </nav>
          <div className="auth-section">
            {/* MetaMask Connection */}
            {!currentAccount ? (
              <button onClick={connectWallet} className="wallet-button">
                Connect MetaMask
              </button>
            ) : (
              <div className="wallet-info">
                Connected: {currentAccount.slice(0, 6)}...{currentAccount.slice(-4)}
              </div>
            )}

            {/* Firebase Auth */}
            {!user ? (
              <div className="login-buttons">
                <button onClick={googleLogin}>Login with Google</button>
              </div>
            ) : (
              <div className="user-info">
                <span>{user.email}</span>
                <button onClick={logout}>Logout</button>
              </div>
            )}
          </div>
        </header>

        <main>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route 
              path="/donate" 
              element={<DonationPage currentAccount={currentAccount} />} 
            />
            <Route 
              path="/ngo-dashboard" 
              element={
                user ? (
                  <NGODashboard 
                    user={user} 
                    currentAccount={currentAccount} 
                  />
                ) : (
                  <div className="login-required">
                    <h2>NGO Login Required</h2>
                    <div className="login-form">
                      <input 
                        type="email" 
                        placeholder="Email" 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)} 
                      />
                      <input 
                        type="password" 
                        placeholder="Password" 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)} 
                      />
                      <button onClick={emailLogin}>Login with Email</button>
                      <button onClick={googleLogin}>Login with Google</button>
                    </div>
                  </div>
                )
              } 
            />

            {/* Admin Panel Route - Only accessible by "admin@example.com" */}
            <Route 
              path="/admin" 
              element={
                user?.email === "admin@example.com" ? (
                  <AdminPanel />
                ) : (
                  <div className="access-denied">
                    <h2>Access Denied</h2>
                    <p>You do not have permission to access this page.</p>
                  </div>
                )
              } 
            />
          </Routes>
        </main>

        <footer>
          <p>© 2025 Blockchain Crowdfunding</p>
        </footer>
      </div>
    </Router>
  );
}

export default App;
